document.addEventListener('DOMContentLoaded', () => {
    const quiz = document.querySelector('.quiz');
    if (!quiz) return;

    const questions = [...quiz.querySelectorAll('.question')];
    const submit = document.createElement('button');
    submit.type = 'button';
    submit.className = 'quiz-submit button button-primary';
    submit.textContent = 'Submit answers';

    const result = document.createElement('p');
    result.className = 'quiz-result';
    result.setAttribute('aria-live', 'polite');
    quiz.append(submit, result);

    submit.addEventListener('click', () => {
        let score = 0;
        let answered = 0;

        questions.forEach((question) => {
            const choices = [...question.querySelectorAll('input[type="radio"]')];
            const selected = choices.find((choice) => choice.checked);
            if (selected) answered += 1;
            choices.forEach((choice, index) => {
                choice.parentElement.classList.remove('correct-answer', 'wrong-answer');
                if (index === 0) choice.parentElement.classList.add('correct-answer');
                if (choice.checked && index !== 0) choice.parentElement.classList.add('wrong-answer');
            });
            if (selected === choices[0]) score += 1;
        });

        result.textContent = `Score: ${score}/${questions.length} | Answered: ${answered}/${questions.length}`;
    });

    const pages = ['introduction-topic.html', 'file-class-topic.html', 'streams-overview.html', 'byte-streams.html', 'character-streams.html', 'buffered-streams.html', 'reading-files.html', 'writing-files.html', 'serialization.html', 'random-access.html', 'file-exceptions.html'];
    const current = window.location.pathname.split('/').pop();
    const position = pages.indexOf(current);
    const navigation = document.createElement('nav');
    navigation.className = 'lesson-navigation';
    navigation.setAttribute('aria-label', 'Lesson navigation');

    const previous = document.createElement('a');
    previous.className = 'button lesson-button';
    previous.textContent = position > 0 ? '<- Previous topic' : '<- Unit 3 map';
    previous.href = position > 0 ? pages[position - 1] : 'index.html';

    const next = document.createElement('a');
    next.className = 'button button-primary lesson-button';
    next.textContent = position < pages.length - 1 ? 'Next topic ->' : 'Finish Unit 3 ->';
    next.href = position < pages.length - 1 ? pages[position + 1] : 'index.html';

    navigation.append(previous, next);
    quiz.after(navigation);
});